# vlamalib

Under construction! Not ready for use yet! Currently experimenting and planning!

Developed by Vladyslav Mazurkevych from Vlamaz (c) 2024

## Examples of How To Use (Buggy Alpha Version)

Calling the function `hello()` from the `vlamalib` package:

```python
from vlamalib import hello

hello()
```
